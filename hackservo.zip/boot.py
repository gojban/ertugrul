import hackservo
from time import sleep
servopin=0
servo=hackservo.servotanimla(servopin)

while True:
    servo.solhiz(30)
    sleep(2)
    servo.saghiz(30)
    sleep(2)