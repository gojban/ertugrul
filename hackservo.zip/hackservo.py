from machine import PWM,Pin
import math
from time import sleep

class servotanimla:
    def __init__(self, pin, freq=50, min_us=600, max_us=2400, angle=360):
    self.min_us = min_us
    self.max_us = max_us
    self.us = 0
    self.freq = freq
    self.angle = angle
    self.pwm = PWM(Pin(pin), freq=freq, duty=0)
    
def pwmdgr(self, us):
    if us == 0:
            self.pwm.duty(0)
            return
        us = min(self.max_us, max(self.min_us, us))
        duty = us * 1024 * self.freq // 1000000
        self.pwm.duty(duty)
        
def solhiz(hiz):
    derece = hiz + 95
    derece = derece % 360
    total_range = self.max_us - self.min_us
    us = self.min_us + total_range * derece // self.angle
    self.pwmdgr(us)
    
    
def saghiz(hiz):
    derece = hiz - 95
    derece = derece % 360
    total_range = self.max_us - self.min_us
    us = self.min_us + total_range * derece // self.angle
    self.pwmdgr(us)
    