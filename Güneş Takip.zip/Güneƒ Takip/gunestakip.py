from machine import Pin, ADC
import hackservo as servo

"""ldrler 3.3vye bağlanıcak"""
"""servo 5vye bağlanıcak"""

sagldr = ADC(Pin(2))
solldr = ADC(Pin(4))
servo_pin = 0
servoderece = 0

servomt = servotanimla(servo_pin)
sagldr.atten(ADC.ATTN_11DB)
solldr.atten(ADC.ATTN_11DB)

while True:
    sagldrdeger = sagldr.read()
    solldrdeger = sagldr.read()
    
    if sagldrdeger<solldrdeger:
        servomt.saghiz(1)
    elif solldrdeger<sagldrdeger:
        servomt.solhiz(1)
    else:
        servomt.saghiz(0)
        servomt.solhiz(0)
        
        
